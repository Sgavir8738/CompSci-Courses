#!/bin/bash

SUB=./submissions
NEWLOG=$SUB/newest.log

if [ ! -e $SUB ]; then
	echo "Directory does not exist"
	exit
fi

if [ ! -e $NEWLOG ]; then
	echo "File does not exist"
	exit
fi

NEWEST=$(head -n 1 $NEWLOG)
NEWTAR=$SUB/$NEWEST.tar.gz

mkdir -p testing
tar --strip-components=2 -zxvf $NEWTAR -C testing
