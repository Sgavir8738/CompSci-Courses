#!/bin/bash

wget https://raw.githubusercontent.com/s7117/csce215labs/main/mnist_condensed.csv

head mnist_condensed.csv
tail -n 8 mnist_condensed.csv | head -n 3
tail -n 8 mnist_condensed.csv | head -n 3 > lab07.out
wc -l  < lab07.out

sed -n '23p' mnist_condensed.csv > lab07.out
cat lab07.out | wc -l
tail -n 8 mnist_condensed.csv | head -n 3 >> lab07.out
sed -n '23p' mnist_condensed.csv >> lab07.out
wc -l lab07.out

mkdir dir{A..Z}
touch dir{A..Z}/file{1..10}.txt
mkdir dir123 dir OLD
mv dir* mnist_condensed.csv OLD
rm -rf OLD
