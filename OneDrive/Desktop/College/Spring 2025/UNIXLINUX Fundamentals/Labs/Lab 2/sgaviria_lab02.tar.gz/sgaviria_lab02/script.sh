#!/bin/bash

hostname
whoami
echo "Hello, World!"
pwd
mkdir dirA dirB dirC
ls
touch fileA fileB fileC
mv fileA dirA/
mv fileB dirB/
mv fileC dirC/
ls dirA
ls dirB
ls dirC
rm -r dirA dirB dirC
